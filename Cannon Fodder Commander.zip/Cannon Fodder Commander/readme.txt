
--- Minimum requirements ---
Windows 8.1 (might work on Windows 7, but can't garantee)
Shader Model 4.0 video card. (GeForce 8800 GTS)+


--- Instructions ---
To run the game execute:
bin/win/Cannon Fodder Commander.exe


--- Credits ---
Create by David St-Louis
on June 28th, 2015
For the Ottawa Game Jam


--- Contact ---
daivuk@gmail.com


--- Sources ---
https://github.com/Daivuk/ojam15
